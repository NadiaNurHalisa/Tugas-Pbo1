public interface HasBrand {
    void brand();
}
