public abstract class Print {
    String price;
    Print(String price){
        this.price = price;
    }

    abstract void price();
}
