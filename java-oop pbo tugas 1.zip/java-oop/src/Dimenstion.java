public interface Dimenstion {
    void dimention();
}
